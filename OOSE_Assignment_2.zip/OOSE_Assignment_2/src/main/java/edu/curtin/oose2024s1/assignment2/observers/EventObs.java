package edu.curtin.oose2024s1.assignment2.observers;

public interface EventObs //Interface for the observer pattern
{
    void update(String message);
}
